# Required Packages

rm(list = ls())        
gc()                  

################################################################################

library(stratEst)
library(openxlsx)
library(writexl)
library(officer)
library(flextable)
set.seed(1)

################################################################################

# Set working directory

setwd("ADD PATH")

# Load data ####################################################################

Data_After_Two_T1 <- read.xlsx("ADD PATH/DataAfterTwo_T1.xlsx")

Data_After_Two_T2 <- read.xlsx("ADD PATH/DataAfterTwo_T2.xlsx")

Data_After_Two_T3 <- read.xlsx("ADD PATH/DataAfterTwo_T3.xlsx")

Data_After_Two_T4 <- read.xlsx("ADD PATH/DataAfterTwo_T4.xlsx")

Data_After_Two_T5 <- read.xlsx("ADD PATH/DataAfterTwo_T5.xlsx")

# stratEst data frame ##########################################################

data.Data_After_Two_T1 <- stratEst.data(data = Data_After_Two_T1, choice = "choice",
                                        input = c("choice","other.choice"),
                                        input.lag = 1)

data.Data_After_Two_T2 <- stratEst.data(data = Data_After_Two_T2, choice = "choice",
                                        input = c("choice","other.choice"),
                                        input.lag = 1)

data.Data_After_Two_T3 <- stratEst.data(data = Data_After_Two_T3, choice = "choice",
                                        input = c("choice","other.choice"),
                                        input.lag = 1)

data.Data_After_Two_T4 <- stratEst.data(data = Data_After_Two_T4, choice = "choice",
                                        input = c("choice","other.choice"),
                                        input.lag = 1)

data.Data_After_Two_T5 <- stratEst.data(data = Data_After_Two_T5, choice = "choice",
                                        input = c("choice","other.choice"),
                                        input.lag = 1)


# stratEst model full set of strategies w/o SGrim etc. #########################

strategies.PD$SGRIM <- NULL
strategies.PD$M1BF <- NULL
strategies.PD$RAND <- NULL
strategies.PD$WSLS <- NULL

# Baseline #####################################################################

# 20 Select (Main Text) ########################################################

model.select.Data_After_Two_20_select_T1 <- stratEst.model(data = data.Data_After_Two_T1,
                                                           strategies = strategies.PD, select="strategies", crit = "icl",
                                                           se = "bootstrap", 
                                                           bs.samples = 1e+4, 
                                                           quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.select.Data_After_Two_20_select_T1$shares)
print(model.select.Data_After_Two_20_select_T1$shares.se)
print(model.select.Data_After_Two_20_select_T1$trembles)
print(model.select.Data_After_Two_20_select_T1$loglike)
print(model.select.Data_After_Two_20_select_T1$icl)

output_list_1 <- list(
  Shares = round(as.data.frame(model.select.Data_After_Two_20_select_T1$shares), 4),
  Shares_SE = round(as.data.frame(model.select.Data_After_Two_20_select_T1$shares.se), 4),
  Trembles = round(as.data.frame(model.select.Data_After_Two_20_select_T1$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.select.Data_After_Two_20_select_T1$loglike, 4)),
  ICL = data.frame(ICL = round(model.select.Data_After_Two_20_select_T1$icl, 4))
)

write_xlsx(output_list_1, "Model_T1_Results_Main.xlsx")

################################################################################
# 20 (Appendix) ################################################################

model.Data_After_Two_20_T1 <- stratEst.model(data = data.Data_After_Two_T1,
                                             strategies = strategies.PD,
                                             se = "bootstrap", 
                                             bs.samples = 1e+4, 
                                             quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.Data_After_Two_20_T1$shares)
print(model.Data_After_Two_20_T1$shares.se)
print(model.Data_After_Two_20_T1$trembles)
print(model.Data_After_Two_20_T1$loglike)
print(model.Data_After_Two_20_T1$icl)

output_list_2 <- list(
  Shares = round(as.data.frame(model.Data_After_Two_20_T1$shares), 4),
  Shares_SE = round(as.data.frame(model.Data_After_Two_20_T1$shares.se), 4),
  Trembles = round(as.data.frame(model.Data_After_Two_20_T1$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.Data_After_Two_20_T1$loglike, 4)),
  ICL = data.frame(ICL = round(model.Data_After_Two_20_T1$icl, 4))
)

write_xlsx(output_list_2, "Model_T1_Results_Appendix.xlsx")

################################################################################

# Hidden 25 ####################################################################

# 20 Select (Main Text) #########################################################

model.select.Data_After_Two_20_select_T2 <- stratEst.model(data = data.Data_After_Two_T2,
                                                           strategies = strategies.PD, select="strategies", crit = "icl",
                                                           se = "bootstrap", 
                                                           bs.samples = 1e+4, 
                                                           quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.select.Data_After_Two_20_select_T2$shares)
print(model.select.Data_After_Two_20_select_T2$shares.se)
print(model.select.Data_After_Two_20_select_T2$trembles)
print(model.select.Data_After_Two_20_select_T2$loglike)
print(model.select.Data_After_Two_20_select_T2$icl)

output_list_1 <- list(
  Shares = round(as.data.frame(model.select.Data_After_Two_20_select_T2$shares), 4),
  Shares_SE = round(as.data.frame(model.select.Data_After_Two_20_select_T2$shares.se), 4),
  Trembles = round(as.data.frame(model.select.Data_After_Two_20_select_T2$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.select.Data_After_Two_20_select_T2$loglike, 4)),
  ICL = data.frame(ICL = round(model.select.Data_After_Two_20_select_T2$icl, 4))
)

write_xlsx(output_list_1, "Model_T2_Results_Main.xlsx")

################################################################################
# 20 (Appendix) ################################################################

model.Data_After_Two_20_T2 <- stratEst.model(data = data.Data_After_Two_T2,
                                             strategies = strategies.PD,  
                                             se = "bootstrap", 
                                             bs.samples = 1e+4, 
                                             quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.Data_After_Two_20_T2$shares)
print(model.Data_After_Two_20_T2$shares.se)
print(model.Data_After_Two_20_T2$trembles)
print(model.Data_After_Two_20_T2$loglike)
print(model.Data_After_Two_20_T2$icl)

output_list_2 <- list(
  Shares = round(as.data.frame(model.Data_After_Two_20_T2$shares), 4),
  Shares_SE = round(as.data.frame(model.Data_After_Two_20_T2$shares.se), 4),
  Trembles = round(as.data.frame(model.Data_After_Two_20_T2$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.Data_After_Two_20_T2$loglike, 4)),
  ICL = data.frame(ICL = round(model.Data_After_Two_20_T2$icl, 4))
)

write_xlsx(output_list_2, "Model_T2_Results_Appendix.xlsx")

################################################################################
# Revealed 25 ##################################################################

# 20 Select (Main Text) ########################################################

model.select.Data_After_Two_20_select_T3 <- stratEst.model(data = data.Data_After_Two_T3,
                                                           strategies = strategies.PD, select="strategies", crit = "icl",
                                                           se = "bootstrap", 
                                                           bs.samples = 1e+4, 
                                                           quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.select.Data_After_Two_20_select_T3$shares)
print(model.select.Data_After_Two_20_select_T3$shares.se)
print(model.select.Data_After_Two_20_select_T3$trembles)
print(model.select.Data_After_Two_20_select_T3$loglike)
print(model.select.Data_After_Two_20_select_T3$icl)

output_list_1 <- list(
  Shares = round(as.data.frame(model.select.Data_After_Two_20_select_T3$shares), 4),
  Shares_SE = round(as.data.frame(model.select.Data_After_Two_20_select_T3$shares.se), 4),
  Trembles = round(as.data.frame(model.select.Data_After_Two_20_select_T3$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.select.Data_After_Two_20_select_T3$loglike, 4)),
  ICL = data.frame(ICL = round(model.select.Data_After_Two_20_select_T3$icl, 4))
)

write_xlsx(output_list_1, "Model_T3_Results_Main.xlsx")

################################################################################
# 20 (Appendix) ################################################################

model.Data_After_Two_20_T3 <- stratEst.model(data = data.Data_After_Two_T3,
                                             strategies = strategies.PD,
                                             se = "bootstrap", 
                                             bs.samples = 1e+4, 
                                             quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.Data_After_Two_20_T3$shares)
print(model.Data_After_Two_20_T3$shares.se)
print(model.Data_After_Two_20_T3$trembles)
print(model.Data_After_Two_20_T3$loglike)
print(model.Data_After_Two_20_T3$icl)

output_list_2 <- list(
  Shares = round(as.data.frame(model.Data_After_Two_20_T3$shares), 4),
  Shares_SE = round(as.data.frame(model.Data_After_Two_20_T3$shares.se), 4),
  Trembles = round(as.data.frame(model.Data_After_Two_20_T3$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.Data_After_Two_20_T3$loglike, 4)),
  ICL = data.frame(ICL = round(model.Data_After_Two_20_T3$icl, 4))
)

write_xlsx(output_list_2, "Model_T3_Results_Appendix.xlsx")

################################################################################
# Hidden 12.5 ##################################################################

# 20 Select (main Text) ########################################################

model.select.Data_After_Two_20_select_T4 <- stratEst.model(data = data.Data_After_Two_T4,
                                                           strategies = strategies.PD, select="strategies", crit = "icl",
                                                           se = "bootstrap", 
                                                           bs.samples = 1e+4, 
                                                           quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.select.Data_After_Two_20_select_T4$shares)
print(model.select.Data_After_Two_20_select_T4$shares.se)
print(model.select.Data_After_Two_20_select_T4$trembles)
print(model.select.Data_After_Two_20_select_T4$loglike)
print(model.select.Data_After_Two_20_select_T4$icl)

output_list_1 <- list(
  Shares = round(as.data.frame(model.select.Data_After_Two_20_select_T4$shares), 4),
  Shares_SE = round(as.data.frame(model.select.Data_After_Two_20_select_T4$shares.se), 4),
  Trembles = round(as.data.frame(model.select.Data_After_Two_20_select_T4$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.select.Data_After_Two_20_select_T4$loglike, 4)),
  ICL = data.frame(ICL = round(model.select.Data_After_Two_20_select_T4$icl, 4))
)

write_xlsx(output_list_1, "Model_T4_Results_Main.xlsx")

################################################################################
# 20 (Appendix)#################################################################

model.Data_After_Two_20_T4 <- stratEst.model(data = data.Data_After_Two_T4,
                                             strategies = strategies.PD,                                                           
                                             se = "bootstrap", 
                                             bs.samples = 1e+4, 
                                             quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.Data_After_Two_20_T4$shares)
print(model.Data_After_Two_20_T4$shares.se)
print(model.Data_After_Two_20_T4$trembles)
print(model.Data_After_Two_20_T4$loglike)
print(model.Data_After_Two_20_T4$icl)

output_list_2 <- list(
  Shares = round(as.data.frame(model.Data_After_Two_20_T4$shares), 4),
  Shares_SE = round(as.data.frame(model.Data_After_Two_20_T4$shares.se), 4),
  Trembles = round(as.data.frame(model.Data_After_Two_20_T4$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.Data_After_Two_20_T4$loglike, 4)),
  ICL = data.frame(ICL = round(model.Data_After_Two_20_T4$icl, 4))
)

write_xlsx(output_list_2, "Model_T4_Results_Appendix.xlsx")

################################################################################
# Revealed 12.5 ################################################################

# 20 Select (Main Text) ########################################################

model.select.Data_After_Two_20_select_T5 <- stratEst.model(data = data.Data_After_Two_T5,
                                                           strategies = strategies.PD, select="strategies", crit = "icl",
                                                           se = "bootstrap", 
                                                           bs.samples = 1e+4, 
                                                           quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.select.Data_After_Two_20_select_T5$shares)
print(model.select.Data_After_Two_20_select_T5$shares.se)
print(model.select.Data_After_Two_20_select_T5$trembles)
print(model.select.Data_After_Two_20_select_T5$loglike)
print(model.select.Data_After_Two_20_select_T5$icl)

output_list_1 <- list(
  Shares = round(as.data.frame(model.select.Data_After_Two_20_select_T5$shares), 4),
  Shares_SE = round(as.data.frame(model.select.Data_After_Two_20_select_T5$shares.se), 4),
  Trembles = round(as.data.frame(model.select.Data_After_Two_20_select_T5$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.select.Data_After_Two_20_select_T5$loglike, 4)),
  ICL = data.frame(ICL = round(model.select.Data_After_Two_20_select_T5$icl, 4))
)

write_xlsx(output_list_1, "Model_T5_Results_Main.xlsx")

################################################################################
# 20 (Appendix) ################################################################

model.Data_After_Two_20_T5 <- stratEst.model(data = data.Data_After_Two_T5,
                                             strategies = strategies.PD,                                            
                                             se = "bootstrap", 
                                             bs.samples = 1e+4, 
                                             quantiles = c(0.05, 0.25, 0.5, 0.75, 0.95))

print(model.Data_After_Two_20_T5$shares)
print(model.Data_After_Two_20_T5$shares.se)
print(model.Data_After_Two_20_T5$trembles)
print(model.Data_After_Two_20_T5$loglike)
print(model.Data_After_Two_20_T5$icl)

output_list_2 <- list(
  Shares = round(as.data.frame(model.Data_After_Two_20_T5$shares), 4),
  Shares_SE = round(as.data.frame(model.Data_After_Two_20_T5$shares.se), 4),
  Trembles = round(as.data.frame(model.Data_After_Two_20_T5$trembles), 4),
  LogLikelihood = data.frame(LogLike = round(model.Data_After_Two_20_T5$loglike, 4)),
  ICL = data.frame(ICL = round(model.Data_After_Two_20_T5$icl, 4))
)

write_xlsx(output_list_2, "Model_T5_Results_Appendix.xlsx")
################################################################################


